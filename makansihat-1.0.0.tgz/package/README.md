# MakanSihat

A Malaysian food calorie and macro tracker built with **TypeScript, React, CSS, and JSON**, using Vite for development and production builds.

This standalone edition runs with npm and deploys as a static website. It does not require Sites, a ChatGPT account, API keys, or a database.

## Features

- 196 Malaysian foods and drinks, with photographs and source notes.
- 71 à la carte items, plus custom foods and favourites.
- Calories, protein, carbohydrates, and fat scaled to your chosen portions.
- Add several lauk to a dish, adjust each quantity independently, and save the whole plate together.
- A dated meal diary, meal and daily totals, and a seven-day calorie view.
- Browser-local saving, with unknown macros shown explicitly rather than counted as zero.

## Run locally

Use **Node.js 22.18 or newer**; Node.js 24 LTS is recommended. Use npm 10 or newer.

```sh
npm ci
npm run dev
```

Open the local URL printed by Vite. To check and build the app:

```sh
npm run check
npm run build
npm start
```

The build goes into `dist/`. The included Node server serves it at `http://127.0.0.1:3000` by default. You can choose another port:

```sh
npm start -- --port 8080
```

## Publish to GitHub

Extract the source ZIP, create your GitHub repository, and push the project files to its `main` branch. The included `.github/workflows/pages.yml` checks the app and builds a GitHub Pages deployment. In **Settings → Pages**, choose **GitHub Actions** as the source.

For the complete steps, manual `npm run deploy` alternative, other hosts, and npm package distribution, see [DEPLOYMENT.md](DEPLOYMENT.md).

## npm commands

| Command           | Purpose                                                                        |
| ----------------- | ------------------------------------------------------------------------------ |
| `npm ci`          | Install the versions recorded in `package-lock.json`.                          |
| `npm run dev`     | Run Vite with live development updates.                                        |
| `npm run check`   | Run TypeScript checking and the automated tests.                               |
| `npm run build`   | Build the static website into `dist/`.                                         |
| `npm start`       | Serve the built website using the included Node CLI.                           |
| `npm run preview` | Preview the Vite build locally.                                                |
| `npm run deploy`  | Check, build, and publish `dist/` to the `gh-pages` branch of your Git origin. |
| `npm pack`        | Check, build, and create an installable npm tarball.                           |

`npm run deploy` publishes a website. `npm publish` is a separate operation that publishes a package to an npm registry; neither happens automatically when you install this project.

## Install the packaged app

The npm tarball includes the built website and the `makansihat` command. From the folder containing the downloaded tarball:

```sh
npm install -g ./makansihat-1.0.0.tgz
makansihat --port 3000
```

Or run it without a global installation:

```sh
npx --package ./makansihat-1.0.0.tgz makansihat --port 3000
```

These local-file commands do not depend on the name being published on npm.

## Project layout

| Path                 | Contents                                                             |
| -------------------- | -------------------------------------------------------------------- |
| `src/`               | React entry point, app interface, and CSS.                           |
| `components/`        | Dish and lauk picker components.                                     |
| `lib/`               | Calorie, macro, portion, and asset-path helpers.                     |
| `data/`              | Food catalogue, nutrition provenance, and image mappings.            |
| `public/foods/`      | Food images, attribution records, and photo licences.                |
| `tests/`             | Regression tests for nutrition totals, portions, and grouped plates. |
| `bin/`               | Node command for serving the built app.                              |
| `.github/workflows/` | GitHub checks and Pages deployment.                                  |

## Data and privacy

The catalogue is broad, not exhaustive. Calories and most macros are estimates for the listed serving. Macro provenance is independent of calorie provenance: a Ministry of Health calorie reference does not verify a recipe's estimated macros. Food and photo source details remain available in the app.

The diary, favourites, custom foods, and guide are saved in the browser's local storage. There is no account sync or server-side diary database. Clearing browser data removes these records. A different browser profile or website origin starts with separate records, so moving the website to a new GitHub domain does not transfer the old site's diary automatically. The storage key remains `makankira-v1` for compatible upgrades on the same origin.

The CSS requests DM Sans from Google Fonts and has system-font fallbacks. Food pictures are included locally. Modern browsers and HTTPS hosting are recommended; localhost also supports the browser APIs used by the app.

## Licence

The authored application code is available under the [MIT licence](LICENSE). Food photographs, fonts, and dependencies retain their own licences. See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) and keep the included photo attribution and GFDL files when redistributing the app.
