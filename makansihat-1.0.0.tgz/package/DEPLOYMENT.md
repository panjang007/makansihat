# Deploying MakanSihat

The standalone app builds into static HTML, JavaScript, CSS, JSON, and images. It needs no API keys or database. Use Node.js 22.18 or newer and npm 10 or newer for building; Node.js 24 LTS is recommended.

## GitHub Pages with GitHub Actions

1. Create an empty repository in your GitHub account. Choose any repository name, such as `makansihat`.
2. Extract the source ZIP. Put its project contents at the repository root, including `package.json`, `package-lock.json`, and the hidden `.github` folder.
3. Commit and push the project to `main`:

```sh
git init
git add .
git commit -m "Add MakanSihat"
git branch -M main
git remote add origin https://github.com/YOUR_ACCOUNT/YOUR_REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your actual repository URL. If the repository is already cloned, use its existing Git setup.

4. In the repository's **Settings → Pages**, set **Source** to **GitHub Actions**.
5. Open **Actions** and run the included Pages workflow if the initial push occurred before Pages was enabled.

The workflow checks and builds the source, then deploys eligible `main` builds. Pull requests run checks without publishing. The workflow uses GitHub's provided token and Pages permissions; it does not need a manually created deployment secret. Your GitHub account and repository settings must allow Pages.

See the official [GitHub Pages workflow documentation](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages) for repository settings and permissions.

## Manual GitHub Pages deployment with npm

Use this as an alternative to the Actions deployment above. First disable the included Pages workflow in GitHub's **Actions** tab, or remove `.github/workflows/pages.yml` from your repository, so future pushes do not start a second publishing route:

```sh
npm ci
npm run deploy
```

The `predeploy` script checks and builds the app, then `gh-pages` publishes `dist/` to the `gh-pages` branch. This command requires a Git repository with an `origin` remote pointing to your GitHub repository and working Git push authentication. In **Settings → Pages**, choose **Deploy from a branch**, then `gh-pages` and `/ (root)`.

Choose the Pages source that matches the deployment method you use. Do not configure a branch deployment and expect the Actions source setting to publish that branch.

## Asset paths and repository names

The default Vite base is `./`, and the app resolves its food images, credit files, and local licence links through the same base. This supports both a domain root and a repository URL such as `https://YOUR_ACCOUNT.github.io/YOUR_REPOSITORY/` without editing each image path.

If a host requires a fixed public prefix, set `VITE_BASE_PATH` before building. For a portable way to set it, create an uncommitted `.env.local` file:

```dotenv
VITE_BASE_PATH=/YOUR_REPOSITORY/
```

Use `/` for a domain root. A fixed prefix should begin and end with `/`. Rebuild after changing it. No secret belongs in a `VITE_` variable: these values become part of the public client build.

For more background, see [Vite's static deployment guide](https://vite.dev/guide/static-deploy.html).

## Other static hosts

For a host that imports a Git repository, use these settings:

| Setting          | Value           |
| ---------------- | --------------- |
| Install command  | `npm ci`        |
| Build command    | `npm run build` |
| Output directory | `dist`          |

You can also upload the contents of `dist/` to an HTTPS static host. Include all of its files, especially `assets/`, `foods/`, and the licence and attribution files. Vite's `preview` server is for local build previews rather than production hosting.

## Run the built app with Node

```sh
npm ci
npm run build
npm start
```

The included CLI defaults to `127.0.0.1:3000`. Command-line options are portable across shells:

```sh
npm start -- --host 0.0.0.0 --port 8080
```

The server also accepts `HOST` and `PORT` environment variables. For a mounted subpath, use the server's `--base-path /YOUR_REPOSITORY/` option together with a compatible build base. Use HTTPS through your host or reverse proxy for public deployment. Run `makansihat --help` after installing the npm tarball to see the CLI options.

## Create and share the npm package

From the source checkout:

```sh
npm ci
npm pack
```

The `prepack` script runs the checks and build before creating `makansihat-1.0.0.tgz`. The tarball contains the built website, CLI, and distribution notices. The GitHub source archive contains the editable source and lockfile.

Install a local copy of the tarball:

```sh
npm install -g ./makansihat-1.0.0.tgz
makansihat --port 3000
```

Or use:

```sh
npx --package ./makansihat-1.0.0.tgz makansihat --port 3000
```

To publish the package to a registry later, choose an available package name or a scope you own, set the package version, and authenticate with your registry. For a public scoped package, npm normally uses `npm publish --access public`. Package-name availability and account access must be checked at publication time. This export has not been published to the npm registry.

See [npm's pack documentation](https://docs.npmjs.com/cli/v11/commands/npm-pack/) for tarball behaviour.

## Records when changing hosts

Diaries remain in each visitor's browser and are separate for each origin. The export keeps the existing `makankira-v1` storage key, so compatible same-origin upgrades retain records. Moving from one domain to another does not copy browser storage. No diary records, credentials, private hosting identifiers, or account data are included in the source archive or npm package.
