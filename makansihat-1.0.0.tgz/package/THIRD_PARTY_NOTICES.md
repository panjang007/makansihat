# Third-party notices

The top-level MIT licence covers the authored MakanSihat application code. It does not replace the licences attached to third-party media, fonts, or dependencies.

## Food photographs

Photo attribution is preserved in:

- `public/foods/credits.json`
- `public/foods/dessert-drink-credits.json`
- `public/foods/GFDL-photo-notices.txt`
- `public/foods/GFDL-1.2.txt`

The production build copies these files to `dist/foods/`. The app exposes the photo sources, authors, licences, and modification notes in its **Food data & sources** view.

The photographs have individual licences, including Creative Commons attribution and share-alike licences, CC0, public-domain designations, and GFDL. Consult the record for the particular image, retain the author/source/licence information, and apply the recorded terms when distributing or modifying it. A representative recipe photograph is marked as a photo example in the app.

`dd-bingka-ubi.jpg` and `dd-sirap.jpg` retain the supplied GFDL licence and author/history notices. Historical mentions of the former MakanKira app name in those notices are retained as modification history.

## Nutrition references

The food catalogue and its provenance notes are in `data/foods.json`. It links to the Malaysian Ministry of Health and MyFCD references used for some values. Most recipe macros are clearly identified as estimates. Referencing these sources does not imply endorsement, and a calorie reference does not validate a separately estimated macro profile. Original source PDFs are linked rather than bundled.

## Fonts

DM Sans is requested from Google Fonts by the CSS; font binaries are not bundled in this export. Copyright 2014 The DM Sans Project Authors. DM Sans is licensed under the SIL Open Font License 1.1. Its upstream licence is available at [google/fonts — DM Sans OFL](https://github.com/google/fonts/blob/main/ofl/dmsans/OFL.txt). The interface falls back to system fonts when the remote font cannot load.

## Runtime dependencies

React and React DOM 19.2.6 use the MIT licence. Lucide React 1.31.0 uses the ISC licence and includes Feather-derived icons under MIT. Their full notices are included below. Dependency packages installed with npm also include their upstream licences.

## Build tooling

Vite 8.0.13 is MIT-licensed. Other build and deployment tools retain the licences included with their npm packages. `package-lock.json` records the dependency versions used by the source project.

## React and React DOM notice

MIT License

Copyright (c) Meta Platforms, Inc. and affiliates.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Lucide notice

ISC License

Copyright (c) 2026 Lucide Icons and Contributors

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

The following Lucide icons are derived from the Feather project:

airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-up-left, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out

The MIT License (MIT) (for the icons listed above)

Copyright (c) 2013-present Cole Bemis

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
